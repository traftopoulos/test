/**
 * Created by Tomasz Gabrysiak @ Infermedica on 06/03/2017.
 *
 * Please provide your own app-id and app-key below.
 * To obtain keys please register at https://developer.infermedica.com.
 */

const settings = {
  'app-id': '',
  'app-key': ''
};

export default settings;
